void ForetAMORCER();
int nForetComposante(int sSommet);
int nForetComplexiteh(int *pnHauteurMaximale);
void ForetFusionner(int ccComposante0, int ccComposante1);
void ForetINITIALISER(int nAntiArbreMax,int bLogN);
void ForetTESTER(int iTest);
void ForetVoir(char *sMessage);
