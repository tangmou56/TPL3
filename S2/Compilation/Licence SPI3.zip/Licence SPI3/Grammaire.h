int bGrammaireAcquerir(char *sGrammaireHomogene);
void GrammaireAMORCER();
void GrammaireINITIALISER();
void GrammaireTESTER(int iTest);
