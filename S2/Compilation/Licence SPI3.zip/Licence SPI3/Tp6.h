void Tp3AMORCER();
void Tp3INITIALISER();
void Tp3TESTER(int iTest);
