//Arcol=Graphe à arcs colorés
void ArcolAMORCER();
void ArcolTESTER(int iTest);
void ArcolVoir(char *sQuoi);
