void Tp4AMORCER();
void Tp4INITIALISER();
void Tp4TESTER(int iTest);
