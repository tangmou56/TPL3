//Grhom pour GRammaire HOMogene
void GrhomAMORCER();
void GrhomCompiler(char *sGrammaireAlgebrique,char *sGrammaireHomogene);
int bGrhomCompiler(char *sGrammaireAlgebrique,char *sGrammaireHomogene,int bAfficher,char *szFichierCible,int *pnRegleEnTout);
void GrhomDecliner(char *sGrammaireAlgebrique,char *sGrammaireHomogene,int uMotLgMax);
void GrhomINITIALISER();
void GrhomTESTER(int iTest);
