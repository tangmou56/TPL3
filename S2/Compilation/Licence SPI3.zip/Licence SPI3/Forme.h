void FormeAMORCER();
char *sFormeFeuille(int noFeuille);
void FormeINITIALISER();
void FormeTESTER(int iTest);
