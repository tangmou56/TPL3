void CycleAMORCER();
void CycleINITIALISER();
void CycleTESTER(int iTest);
