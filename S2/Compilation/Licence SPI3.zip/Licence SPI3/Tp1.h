void Tp1AMORCER();
void Tp1Distancier(graf *pgG,int bAfficher);
void Tp1INITIALISER();
void Tp1TESTER(int iTest);
