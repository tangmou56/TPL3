void CouplageAMORCER();
void CouplageINITIALISER();
int bCouplageOptimiser(graf *pgG,int bPonderer,int bMaximiserSinonMinimiser);
int bCouplageParfait(graf *pgG);
void CouplageTESTER(int iTest);
