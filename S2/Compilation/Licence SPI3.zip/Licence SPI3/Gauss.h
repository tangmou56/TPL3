void GaussAMORCER();
void GaussTESTER(int iTest);