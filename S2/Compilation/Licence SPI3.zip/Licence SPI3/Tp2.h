void Tp2AMORCER();
void Tp2INITIALISER();
void Tp2TESTER(int iTest);
