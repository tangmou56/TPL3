enum eAsyntMode {mAsyntSyntaxe,mAsyntSemantique};
void AsyntAMORCER();
int bAsyntAnalyser(int amMode);
void AsyntDenoncer();
void AsyntINITIALISER();
void AsyntTESTER(int iTest);
