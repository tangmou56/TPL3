#ifndef _MESSAGES_H_
#define _MESSAGES_H_

#define MESSAGES_TAILLE  2048
#define MESSAGES_NB	 1000000

/* Definition des types de base */

typedef enum booleen { FAUX , VRAI } booleen_t ; 

#endif
